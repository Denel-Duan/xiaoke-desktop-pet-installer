﻿param(
  [switch]$SkipTest,
  [switch]$NoLaunch
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$Utf8NoBom = New-Object System.Text.UTF8Encoding -ArgumentList $false

function Write-Step {
  param([string]$Message)
  Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Get-ComPortFromName {
  param([string]$Name)
  if ($Name -match 'COM(\d+)') { return "COM$($Matches[1])" }
  return $null
}

$PackageRoot = Split-Path -Parent $PSCommandPath
$SourceSkill = Join-Path $PackageRoot "clawd-mochi-cx"
$CodexHome = Join-Path $env:USERPROFILE ".codex"
$HooksDir = Join-Path $CodexHome "hooks"
$SkillDir = Join-Path (Join-Path $CodexHome "skills") "clawd-mochi-cx"
$GlobalHooks = Join-Path $CodexHome "hooks.json"
$TemplatePath = Join-Path $SourceSkill "assets\hooks.json"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"

if (-not (Test-Path -LiteralPath (Join-Path $SourceSkill "SKILL.md"))) {
  throw "安装包不完整：找不到 clawd-mochi-cx\SKILL.md"
}
if (-not (Test-Path -LiteralPath $TemplatePath)) {
  throw "安装包不完整：找不到 assets\hooks.json"
}

Write-Step "检查 Codex"
$CodexCommand = Get-Command codex -ErrorAction SilentlyContinue
if ($null -eq $CodexCommand) {
  Write-Warning "未在 PATH 中找到 codex 命令。桌面端仍可使用，但 /hooks 信任步骤需要 Codex CLI。"
} else {
  Write-Host "已找到 Codex：$($CodexCommand.Source)"
}

Write-Step "备份现有 Mochi/Codex Hook 文件"
New-Item -ItemType Directory -Force -Path $CodexHome, $HooksDir, (Split-Path -Parent $SkillDir) | Out-Null
foreach ($Path in @(
  $GlobalHooks,
  (Join-Path $HooksDir "clawd-mochi-codex.cmd"),
  (Join-Path $HooksDir "clawd-mochi-codex.ps1")
)) {
  if (Test-Path -LiteralPath $Path) {
    Copy-Item -LiteralPath $Path -Destination "$Path.backup-$Stamp" -Force
    Write-Host "已备份：$Path.backup-$Stamp"
  }
}

Write-Step "安装 Skill 和串口发送脚本"
New-Item -ItemType Directory -Force -Path $SkillDir | Out-Null
Copy-Item -Path (Join-Path $SourceSkill "*") -Destination $SkillDir -Recurse -Force
Copy-Item -LiteralPath (Join-Path $SourceSkill "assets\clawd-mochi-codex.cmd") -Destination $HooksDir -Force
Copy-Item -LiteralPath (Join-Path $SourceSkill "assets\clawd-mochi-codex.ps1") -Destination $HooksDir -Force
Copy-Item -LiteralPath $TemplatePath -Destination (Join-Path $HooksDir "hooks.template.json") -Force

Write-Step "合并 Codex Hooks（保留其他已有 Hook）"
if (Test-Path -LiteralPath $GlobalHooks) {
  try {
    $Config = Get-Content -Raw -Encoding UTF8 -LiteralPath $GlobalHooks | ConvertFrom-Json
  } catch {
    throw "现有 $GlobalHooks 不是有效 JSON；原文件已备份，未覆盖。"
  }
} else {
  $Config = [pscustomobject]@{}
}

if ($null -eq $Config.PSObject.Properties["hooks"]) {
  $Config | Add-Member -NotePropertyName "hooks" -NotePropertyValue ([pscustomobject]@{})
}

$Template = Get-Content -Raw -Encoding UTF8 -LiteralPath $TemplatePath | ConvertFrom-Json
foreach ($EventProperty in $Template.hooks.PSObject.Properties) {
  $EventName = $EventProperty.Name
  $NewGroups = @($EventProperty.Value | ForEach-Object {
    ($_ | ConvertTo-Json -Depth 30 -Compress) | ConvertFrom-Json
  })

  foreach ($Group in $NewGroups) {
    foreach ($Hook in @($Group.hooks)) {
      if ($null -ne $Hook.PSObject.Properties["command"]) {
        $Hook.command = ([string]$Hook.command).Replace("__HOOKS_DIR__", $HooksDir)
      }
    }
  }

  $ExistingProperty = $Config.hooks.PSObject.Properties[$EventName]
  $KeptGroups = @()
  if ($null -ne $ExistingProperty) {
    $KeptGroups = @($ExistingProperty.Value | Where-Object {
      $Serialized = $_ | ConvertTo-Json -Depth 30 -Compress
      $Serialized -notmatch 'clawd-mochi-codex\.(cmd|ps1|sh)'
    })
    $ExistingProperty.Value = @($KeptGroups + $NewGroups)
  } else {
    $Config.hooks | Add-Member -NotePropertyName $EventName -NotePropertyValue @($NewGroups)
  }
}

$ConfigJson = $Config | ConvertTo-Json -Depth 30
[System.IO.File]::WriteAllText($GlobalHooks, $ConfigJson, $Utf8NoBom)
$null = Get-Content -Raw -Encoding UTF8 -LiteralPath $GlobalHooks | ConvertFrom-Json
Write-Host "Hooks 已写入：$GlobalHooks"

Write-Step "检测 Mochi 串口"
$Entities = @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue)
$Candidates = @()

foreach ($Device in @($Entities | Where-Object {
  $_.PNPDeviceID -match 'VID_303A&PID_1001' -and $_.Name -match 'COM\d+'
})) {
  $Port = Get-ComPortFromName $Device.Name
  if ($Port) { $Candidates += [pscustomobject]@{ Port=$Port; Kind="ESP32-C3 原生 USB"; Name=$Device.Name } }
}

if ($Candidates.Count -eq 0) {
  foreach ($Device in @($Entities | Where-Object {
    $_.PNPDeviceID -match 'VID_1A86&PID_(7523|5523)' -and $_.Name -match 'COM\d+'
  })) {
    $Port = Get-ComPortFromName $Device.Name
    if ($Port) { $Candidates += [pscustomobject]@{ Port=$Port; Kind="CH340"; Name=$Device.Name } }
  }
}

$SelectedPort = $null
if ($Candidates.Count -eq 1) {
  $SelectedPort = $Candidates[0].Port
} elseif ($Candidates.Count -gt 1) {
  Write-Host "发现多个候选串口："
  $Candidates | ForEach-Object { Write-Host "  $($_.Port)  $($_.Kind)  $($_.Name)" }
  $Choice = (Read-Host "请输入 Mochi 的 COM 端口（例如 COM5）").Trim().ToUpperInvariant()
  if ($Choice -match '^COM\d+$') { $SelectedPort = $Choice }
}

if ($SelectedPort) {
  [System.IO.File]::WriteAllText((Join-Path $env:USERPROFILE ".clawd_mochi_com"), $SelectedPort, $Utf8NoBom)
  Write-Host "已选择：$SelectedPort" -ForegroundColor Green
} else {
  Write-Warning "未自动找到 Mochi。安装已完成；请确认数据线和 CH340 驱动后重新运行安装器。"
}

if ($SelectedPort -and -not $SkipTest) {
  Write-Step "发送测试表情"
  $Launcher = Join-Path $HooksDir "clawd-mochi-codex.cmd"
  $env:CLAWD_MOCHI_DEBUG = "1"
  & $Launcher -State thinking
  Start-Sleep -Milliseconds 700
  & $Launcher -State done
  Remove-Item Env:CLAWD_MOCHI_DEBUG -ErrorAction SilentlyContinue
  Write-Host "已发送 thinking 和 done；设备应显示对应动画。" -ForegroundColor Green
}

Write-Step "安装完成"
if ($NoLaunch) {
  Write-Host "自动化验证模式：跳过 Codex 交互启动。"
} elseif ($null -ne $CodexCommand) {
  Write-Host "接下来会自动打开 Codex 终端。" -ForegroundColor Green
  Write-Host "打开后只需：输入 /hooks，确认 Mochi Hooks 的 Active 为 1，然后按 Esc、Ctrl+C 返回安装器。" -ForegroundColor Yellow
  $null = Read-Host "准备好后按回车"
  & $CodexCommand.Source

  Write-Step "启动 Codex Windows 桌面端"
  $DesktopProcesses = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ExecutablePath -match '(?i)\\WindowsApps\\OpenAI\.Codex'
  })
  if ($DesktopProcesses.Count -gt 0) {
    Write-Host "检测到桌面端仍在后台运行。为了加载刚信任的 Hooks，需要重启它。" -ForegroundColor Yellow
    $RestartChoice = (Read-Host "确认没有正在执行的任务后，输入 Y 自动重启；输入其他内容跳过").Trim()
    if ($RestartChoice -match '(?i)^(y|yes)$') {
      foreach ($Process in $DesktopProcesses) {
        Stop-Process -Id $Process.ProcessId -Force -ErrorAction SilentlyContinue
      }
      Start-Sleep -Seconds 2
    }
  }

  $DesktopApp = Get-StartApps | Where-Object { $_.AppID -match '(?i)^OpenAI\.Codex' } | Select-Object -First 1
  if ($null -ne $DesktopApp) {
    Start-Process explorer.exe -ArgumentList "shell:AppsFolder\$($DesktopApp.AppID)"
    Write-Host "已启动桌面端。发送一条普通消息即可测试。" -ForegroundColor Green
  } else {
    Write-Host "未找到桌面端快捷入口，请手动打开 Codex 桌面端。" -ForegroundColor Yellow
  }
} else {
  Write-Host "安装文件已经就绪。安装 Codex CLI 后运行 codex，再输入 /hooks 完成一次信任。" -ForegroundColor Yellow
}





