@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0clawd-mochi-codex.ps1" %*
exit /b %ERRORLEVEL%
