﻿# 03 · Firmware Design (Wired / USB)

The firmware is a single Arduino sketch (`clawd_mochi.ino`) plus a `rle_sprite.h`
header and 13 sprite data headers, **all bundled in the sketch folder**. On the
wired build, four concerns matter at runtime, in dependency order:

1. Sprite assets (RLE-compressed headers, self-contained in the sketch folder)
2. USB serial input (read one state word per line from the PC)
3. Sprite state machine (which animation is current, which frame)
4. Non-blocking frame loop (advance sprites without blocking serial reads)

Libraries: `Adafruit_GFX`, `Adafruit_ST7789`, `SPI`. The sketch also `#include`s
`WiFi`, `WebServer`, `ESPmDNS`, and `Preferences` (they ship with the ESP32
core), but **the wired build never uses them** — they're retained only for source
compatibility with the original WiFi project and are dead code at runtime. You
can delete that whole group to shrink the binary if you like.

---

## 1. Sprite assets

The 13 sprite headers ship **inside the sketch folder** next to
`clawd_mochi.ino` — no copying or external download needed. They are included
with plain relative paths:

```
sprite_idle.h       sprite_thinking.h   sprite_debugger.h
sprite_typing.h     sprite_building.h   sprite_happy.h
sprite_confused.h   sprite_alert.h      sprite_sleeping.h
sprite_conducting.h sprite_wizard.h     sprite_sweeping.h
sprite_beacon.h
```

Each file exposes:
```c
#define {NAME}_WIDTH       <w>
#define {NAME}_HEIGHT      <h>
#define {NAME}_FRAME_COUNT <n>
#define {NAME}_TRANSPARENT_KEY 0x18C5   // dark navy — all sprites use this

static const uint32_t {name}_frame_offsets[n + 1]; // byte offsets into rle_data
static const uint16_t {name}_rle_data[];            // RLE (value, run_count) pairs
```

### Flash budget

| Sprite | W×H | Frames |
|--------|-----|--------|
| idle | 72×51 | 96 |
| thinking | 76×92 | 32 |
| debugger | 86×43 | 96 |
| typing | 86×78 | 12 |
| building | 124×75 | 8 |
| happy | 124×89 | 20 |
| confused | 152×113 | 48 |
| alert | 120×98 | 40 |
| sleeping | 92×96 | 36 |
| conducting | 76×78 | 16 |
| wizard | 72×129 | 48 |
| sweeping | 138×56 | 12 |
| beacon | 134×127 | 64 |

Total sprites ≈ 1 MB. Firmware ≈ 1 MB. Fits in 4 MB flash with the **Huge APP**
partition scheme (see `references/07`).

---

## 2. USB serial input (replaces WiFi + HTTP server)

On the wired build there is **no WiFi join and no HTTP server**. The PC writes one
state word per line to the device's USB serial port; the firmware reads it in
`loop()`. Three small functions do all the work:

### `serialTick()` — accumulate a line

Called every `loop()` iteration. It reads available bytes into a fixed buffer and,
on a newline (`\n` or `\r`), hands the completed line to `handleSerialLine()`.
Over-long lines (≥ 39 chars) are discarded as a safety guard.

```cpp
void serialTick() {
  static char buf[40];
  static uint8_t len = 0;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (len > 0) { buf[len] = '\0'; len = 0; handleSerialLine(String(buf)); }
    } else if (len < sizeof(buf) - 1) {
      buf[len++] = c;
    } else {
      len = 0;   // line too long → drop (guard)
    }
  }
}
```

### `handleSerialLine()` — dispatch

Trims the line, ignores empties, routes the optional resting-look commands, and
sends everything else to `applyState()`:

```cpp
// one word per line: thinking|reading|coding|running|delegating|planning|
//   compacting|notify|done|error|waiting|sleep|idle
// optional commands: face:0|1|2  /  bg:#RRGGBB  /  light:on|off
void handleSerialLine(String line) {
  line.trim();
  if (line.length() == 0) return;
  if (line.startsWith("face:")) {
    manualView = (uint8_t)constrain(line.substring(5).toInt(), 0, 2);
    showManual(); return;
  }
  if (line.startsWith("bg:")) {
    manualBg = hexToRgb565(line.substring(3));
    if (mood == MOOD_MANUAL || mood == MOOD_IDLE) showManual();
    return;
  }
  if (line == "light:on")  { setBacklight(true);  return; }
  if (line == "light:off") { setBacklight(false); return; }
  applyState(line);   // everything else = a state word
}
```

### `applyState()` — the state machine entry point

Maps a state word to a `MOOD_*` and draws the first frame. It also implements the
resilience rules (sticky thinking, same-mood guard, fixed orange background for
working states):

```cpp
void applyState(const String& s) {
  lastEventMs = millis();
  showingInfo = false;   // first real event dismisses the boot info screen

  // sticky "thinking": hold ~1.1 s before tool states can override it
  bool activeTool = (s == "coding" || s == "reading" || s == "running" ||
                     s == "delegating" || s == "compacting");
  if (activeTool && millis() < thinkingUntil) return;

  termMode = false;
  animBgColor = C_ORANGE;            // all working states use fixed brand orange

  if (s == "thinking") { mood = MOOD_THINKING; thinkingUntil = millis() + 1100; ... }
  else if (s == "reading")    { if (mood != MOOD_READING)    { ... } }
  else if (s == "coding")     { if (mood != MOOD_CODING)     { ... } }
  else if (s == "running")    { if (mood != MOOD_RUNNING)    { ... } }
  else if (s == "delegating") { if (mood != MOOD_DELEGATING) { ... } }
  else if (s == "compacting") { if (mood != MOOD_COMPACTING) { ... } }
  else if (s == "planning")   { mood = MOOD_PLANNING; ... }
  else if (s == "notify")     { mood = MOOD_NOTIFY;   ... }
  else if (s == "done")       { mood = MOOD_DONE;     ... }
  else if (s == "error")      { mood = MOOD_ERROR;    ... }
  else if (s == "waiting")    { mood = MOOD_WAITING;  ... }
  else if (s == "sleep")      { mood = MOOD_SLEEP;    ... }
  else                        { showManual(); }       // idle / unknown → rest
}
```

> **Native USB never auto-resets.** On boards with a USB-serial bridge (CP2102 /
> CH340), opening the port toggles DTR/RTS, which the bridge wires to the chip's
> reset/boot lines — so the board reboots whenever a program opens the port. The
> ESP32-C3 Super Mini uses the chip's **native** USB peripheral, which has **no
> such auto-reset circuit**: opening the COM port from the PowerShell sender does
> **not** reset the chip. That's exactly what we want — every hook opens the port,
> writes a word, and closes it, dozens of times per turn, without ever rebooting
> the mascot. (The sender additionally keeps RTS deasserted and only raises DTR as
> a courtesy "terminal connected" flag.)

---

## 3. Sprite state machine

### Mood ids & metadata tables

```cpp
#define MOOD_IDLE 0
#define MOOD_THINKING 1
#define MOOD_READING 2
#define MOOD_CODING 3
#define MOOD_RUNNING 4
#define MOOD_DONE 5
#define MOOD_ERROR 6
#define MOOD_WAITING 7
#define MOOD_SLEEP 8
#define MOOD_DELEGATING 9
#define MOOD_PLANNING 10
#define MOOD_COMPACTING 11
#define MOOD_NOTIFY 12
#define NUM_SPRITES 13
#define MOOD_MANUAL 99

static const uint16_t *const spriteRLE[NUM_SPRITES] = {
  idle_rle_data, thinking_rle_data, debugger_rle_data, typing_rle_data,
  building_rle_data, happy_rle_data, confused_rle_data, alert_rle_data,
  sleeping_rle_data, conducting_rle_data, wizard_rle_data, sweeping_rle_data,
  beacon_rle_data,
};
static const uint32_t *const spriteOffsets[NUM_SPRITES] = { idle_frame_offsets, ... };
static const uint16_t spriteW[NUM_SPRITES]          = { 72, 76, 86, 86,124,124,152,120, 92, 76, 72,138,134};
static const uint16_t spriteH[NUM_SPRITES]          = { 51, 92, 43, 78, 75, 89,113, 98, 96, 78,129, 56,127};
static const uint8_t  spriteFrameCount[NUM_SPRITES] = { 96, 32, 96, 12,  8, 20, 48, 40, 36, 16, 48, 12, 64};
static const uint16_t spriteFpsMs[NUM_SPRITES]      = {125,125,125,125,125,125,125,125,250,125,125,125,125};
//                                                     ~8 fps for all; sleep at ~4 fps
```

### SRAM budget

Largest decode buffer is confused: 152×113×2 = **34,352 bytes** (the other sprites
are all smaller — beacon is 134×127 = 17 KB). With the radio off, SRAM is roomy;
34 KB is safe.

```cpp
#define SPRITE_MAX_PIXELS (152 * 113)
static uint16_t spriteBuf[SPRITE_MAX_PIXELS];   // shared decode buffer
```

### `drawSpriteFrame()`

```cpp
void drawSpriteFrame(uint8_t moodId, uint8_t frame, bool fullRedraw) {
  if (moodId >= NUM_SPRITES) return;
  // 1. Look up sprite metadata
  const uint16_t *rle  = spriteRLE[moodId];
  const uint32_t *offs = spriteOffsets[moodId];
  int w = spriteW[moodId], h = spriteH[moodId];
  uint16_t bg = (moodId == MOOD_SLEEP) ? C_DARKBG : animBgColor;

  // 2. RLE decode with inline transparent-key → bg substitution (one pass)
  const uint16_t *src = rle + offs[frame];
  int pos = 0, pixels = w * h;
  while (pos < pixels) {
    uint16_t val = *src++, cnt = *src++;
    uint16_t fill = (val == TRANSPARENT_KEY) ? bg : val;
    while (cnt-- && pos < pixels) spriteBuf[pos++] = fill;
  }

  // 3. Uniform sizing: scale so the longer side ~= 210 px, capped at 232 px
  //    per axis. Every sprite looks equally large regardless of native size.
  const float TARGET = 210.0f;
  float sf = TARGET / (float)max(w, h);
  if (w * sf > 232.0f) sf = 232.0f / w;
  if (h * sf > 232.0f) sf = 232.0f / h;
  int sw = (int)(w * sf + 0.5f), sh = (int)(h * sf + 0.5f);
  int ox = (240 - sw) / 2, oy = (240 - sh) / 2;   // centre on 240×240

  // 4. Background: full clear or 4-strip margin update (anti-flicker)
  if (fullRedraw) {
    tft.fillScreen(bg);
  } else {
    tft.fillRect(0, 0,       240, oy,             bg);  // top
    tft.fillRect(0, oy + sh, 240, 240 - oy - sh,  bg);  // bottom
    tft.fillRect(0, oy,      ox,  sh,             bg);  // left
    tft.fillRect(ox + sw, oy, 240 - ox - sw, sh,  bg);  // right
  }

  // 5. Nearest-neighbour scaled blit (integer ratio maps dest → source pixel)
  static uint16_t rowBuf[240];
  tft.startWrite();
  tft.setAddrWindow(ox, oy, sw, sh);
  for (int dy = 0; dy < sh; dy++) {
    const uint16_t *srcRow = &spriteBuf[((dy * h) / sh) * w];
    for (int dx = 0; dx < sw; dx++) rowBuf[dx] = srcRow[(dx * w) / sw];
    tft.writePixels(rowBuf, sw);
  }
  tft.endWrite();
}
```

**Why uniform scaling?** Native sprite widths range from 72 px (idle) to 152 px
(confused). The earlier integer-only scale forced any sprite wider than 120 px
down to 1× — so running/done/error rendered tiny while narrow sprites got 2–3×.
Fractional nearest-neighbour scaling to a fixed target makes every expression the
same on-screen size; nearest-neighbour keeps the crisp pixel-art look. (A small
per-sprite `spriteNudgeX/Y` table re-centers any sprite that looks off, e.g.
sleeping is nudged +16 px in X.)

**Why the 4-strip pattern instead of `fillScreen`?** Clearing the entire 240×240
display (57,600 pixels) every frame at 40 MHz SPI costs most of the frame budget
at 8 fps. The 4 strips clear only the borders around the scaled sprite, leaving
time for the decode + blit. Result: smooth animation with no visible flicker.

### Background colour rules

| State | `animBgColor` | Why |
|-------|--------------|-----|
| Any Codex working state | `C_ORANGE` | Fixed brand orange — set in `applyState()` |
| idle / manual resting | `manualBg` | User's `bg:`-chosen color — set in `showManual()` |
| MOOD_SLEEP | always `C_DARKBG` | Dark feel for sleeping, overrides animBgColor |

This means your `bg:` color **cannot bleed into** the Codex expressions.

---

## 4. Non-blocking frame loop

```cpp
void loop() {
  serialTick();   // read USB serial events (replaces HTTP handleClient + WiFi watchdog)

  unsigned long now = millis();

  // Boot info screen ("USB Ready") auto-dismisses to sleep after ~8 s
  if (showingInfo && staConnected && now - infoShownAt > 8000) {
    showingInfo = false;
    mood = MOOD_SLEEP; moodFrame = 0; moodTick = now;
    drawSpriteFrame(MOOD_SLEEP, 0, true);
  }

  // Self-healing timers:
  if (mood == MOOD_DONE && now - moodTick > 5000) showManual();
  if (working_mood && now - lastEventMs > 120000) showManual();

  // Determine which sprite to animate (mood 0-12 direct;
  // MOOD_MANUAL → idle or sleeping sprite depending on manualView)
  uint8_t animMood = ...;

  if (animMood < NUM_SPRITES && !showingInfo &&
      now - moodTick >= spriteFpsMs[animMood]) {
    moodTick  = now;
    moodFrame = (moodFrame + 1) % spriteFrameCount[animMood];
    drawSpriteFrame(animMood, moodFrame, false);  // false = 4-strip update
  }
}
```

A single sprite animation keeps playing in `loop()` until the next serial line
changes the mood. No blocking `delay()` calls in the animation path — the serial
reader runs every iteration, so events are picked up promptly.

> **`staConnected` is repurposed.** In the WiFi edition this flag meant "joined
> the LAN". On the wired build `setup()` sets it `true` to mean "**USB ready**",
> so the same boot-info → sleep timeout logic works unchanged. It's the one WiFi
> variable that's still live.

---

## 5. The resting look (replaces the web controller)

There is no phone web page on the wired build. The resting appearance is set by
optional serial commands handled in `handleSerialLine()` and applied by
`showManual()`:

| Serial line | manualView | Resting sprite |
|-------------|-----------|----------------|
| `face:0` | 0 | idle (bobbing) |
| `face:1` | 1 | sleeping (closed-eye loops) |
| `face:2` | 2 | Codex terminal text view (no sprite) |
| `bg:#RRGGBB` | — | sets `manualBg`; repaints the resting sprite |
| `light:on` / `light:off` | — | backlight on/off |

`face:`/`bg:` affect only the resting state; working expressions always use their
fixed orange look. The large `INDEX_HTML` / `CONFIG_HTML` PROGMEM strings and all
`routeXxx()` HTTP handlers remain in the source as dead code (never registered, no
`WebServer::begin()`), purely for source compatibility — they can be deleted to
reclaim flash.

---

## File layout

Everything the firmware needs lives in one folder — open `clawd_mochi.ino` in
Arduino IDE and compile, no extra setup:

```
clawd_mochi/
└── clawd_mochi/
    ├── clawd_mochi.ino      ← main sketch (serial reader, state machine, loop)
    ├── rle_sprite.h         ← TRANSPARENT_KEY constant + naming doc
    ├── sprite_idle.h        ┐
    ├── sprite_thinking.h    │
    ├── sprite_debugger.h    │
    ├── sprite_typing.h      │
    ├── sprite_building.h    │
    ├── sprite_happy.h       │ 13 sprite headers,
    ├── sprite_confused.h    │ bundled in the sketch
    ├── sprite_alert.h       │ folder (self-contained)
    ├── sprite_sleeping.h    │
    ├── sprite_conducting.h  │
    ├── sprite_wizard.h      │
    ├── sprite_sweeping.h    │
    └── sprite_beacon.h      ┘
```

