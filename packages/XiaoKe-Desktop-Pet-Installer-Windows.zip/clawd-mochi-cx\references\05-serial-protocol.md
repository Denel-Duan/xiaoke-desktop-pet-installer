﻿# 05 · Serial Protocol Reference (串口行协议 / Wired · USB)

The wired mascot has **no HTTP server and no WiFi**. It is driven entirely over
its **USB serial port**. The PC writes short text lines; the firmware reads them
in `loop()` (`serialTick` → `handleSerialLine` → `applyState`) and switches the
sprite. This file is the complete contract.

## Link settings

| Setting | Value |
|---------|-------|
| Port | the device's COM port (Windows) / `/dev/tty.usb*` (*nix) — Espressif native USB `VID_303A&PID_1001` |
| Baud | **115200** |
| Framing | 8 data bits, no parity, 1 stop bit (**8N1**) |
| Line ending | **newline** (`\n`); a trailing `\r` is tolerated/ignored |
| Direction | **host → device only** (the device sends nothing back you need to read) |

Each command is **one line**: write the word, then `\n`. The firmware trims
whitespace and ignores empty lines. Lines longer than 39 chars are discarded
(safety guard).

The `clawd-mochi-codex.ps1` sender (see `04`) opens the port with exactly these
settings — RTS deasserted (so it never trips a reset), DTR raised as a "terminal
connected" flag — and writes one line per Codex event. You don't normally
type these by hand.

## The Codex channel — state words (13)

Send exactly one of these words to set the expression. These thirteen are what the
Codex hooks send.

| Line | Sprite | Animation | Meaning |
|------|--------|-----------|---------|
| `idle` | sprite_idle | gentle floating bob | not working; show the resting face + color |
| `thinking` | sprite_thinking | particle swirl upward | a turn just started |
| `reading` | sprite_debugger | eye-scanner sweep | reading/searching code or the web |
| `coding` | sprite_typing | fingers typing | editing/writing files |
| `running` | sprite_building | crane arm swinging | running a shell command |
| `delegating` | sprite_conducting | conductor waving | subagent or thread handoff |
| `planning` | sprite_wizard | wizard casting | update-plan / plan-mode activity |
| `waiting` | sprite_alert | alert flash | needs your approval / answer |
| `compacting` | sprite_sweeping | crab sweeping up | compacting the conversation context |
| `notify` | sprite_beacon | beacon pulse | a desktop notification / needs attention |
| `done` | sprite_happy | bounce + sparkle | turn finished (auto-relaxes to rest after ~5 s) |
| `error` | sprite_confused | dizzy spiral | something failed (sent manually) |
| `sleep` | sprite_sleeping | slow Zzz drift | session ended |

Any **unrecognized** word is treated as `idle` (safe default).

Example (Windows PowerShell, one-off — in practice the sender does this for you):
```powershell
$p = New-Object System.IO.Ports.SerialPort 'COM49',115200,([System.IO.Ports.Parity]::None),8,([System.IO.Ports.StopBits]::One)
$p.NewLine = "`n"; $p.RtsEnable = $false; $p.DtrEnable = $true
$p.Open(); $p.WriteLine('coding'); $p.Close()
```

## Optional commands — customize the resting look

The wired build has no phone web controller, but you can still tune the **resting
appearance** by sending these lines (e.g. once at login, or from your own script).
They are optional; the mascot works fine on defaults (orange background, normal
eyes, backlight on).

| Line | Effect |
|------|--------|
| `face:0` | resting face = normal eyes (idle sprite, default) |
| `face:1` | resting face = squish / sleeping eyes |
| `face:2` | resting face = Codex terminal view |
| `bg:#RRGGBB` | resting background color (e.g. `bg:#CD3400`); a bare `bg:CD3400` also works |
| `light:on` | backlight on |
| `light:off` | backlight off (screen dark, device still running) |

`face:` and `bg:` affect only the **resting** state. Codex's working
expressions (`coding`/`running`/…) always use their fixed orange look and are
never recolored — see `06`.

## Behavior notes (mirrors the firmware)

- **Sticky "thinking".** After `thinking`, the tool states `coding`/`reading`/
  `running`/`delegating`/`compacting` are held off for ~1.1 s so the thinking face
  is always visible at the start of a turn, even when Codex fires a tool
  immediately.
- **Same-mood guard.** Repeating a working word (e.g. several `coding` lines in a
  row) does **not** restart the animation — it only refreshes the activity timer.
- **`done` auto-relaxes.** After ~5 s on `done`, the mascot returns to its resting
  face on its own.
- **Activity timeout.** If a working state (`thinking`/`reading`/`coding`/
  `running`/`delegating`/`planning`/`compacting`/`notify`) gets no new line for
  **120 s**, the mascot falls back to rest — so a dropped event never strands it
  on the wrong face. (`waiting` and `done` are intentionally excluded; waiting on
  you should persist.)
- **Boot.** On power-up the device shows a splash and logo, then a green **"USB
  Ready"** info screen, then drifts into the sleeping sprite after ~8 s until the
  first line arrives.

## What was removed vs. the WiFi version

The wired firmware drops the entire network layer at runtime: no `WiFi`, no
`WebServer`, no `/event` HTTP endpoint, no `/cmd` `/redraw` `/state` `/speed`
`/backlight` `/canvas` `/wifi*` routes, no mDNS / `clawd-mochi.local`, and no
on-device WiFi config portal or phone web controller. Everything those endpoints
did is now either (a) automatic (the resting face), or (b) a serial line
(`face:` / `bg:` / `light:`). The HTTP route handlers and HTML pages remain in the
source as dead code for compatibility, but the wired firmware never starts the
web server.

