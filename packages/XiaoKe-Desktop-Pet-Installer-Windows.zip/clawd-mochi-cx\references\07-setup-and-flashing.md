﻿# 07 · Setup & Flashing (Wired / USB)

End-to-end procedure to take a board to a working **wired** mascot. The mascot
talks to the PC purely over the USB cable — no WiFi anywhere.

## 1. Toolchain

- **Arduino IDE 2.x** (or arduino-cli).
- **ESP32 board support** — in Preferences → "Additional boards manager URLs"
  add:
  `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
  then install **"esp32 by Espressif Systems"** from the Boards Manager.
- **Libraries** (Library Manager): `Adafruit GFX Library`, `Adafruit ST7735 and
  ST7789 Library`. (The sketch still `#include`s `WiFi`/`WebServer`/`ESPmDNS`/
  `Preferences`, which ship with the ESP32 core — they're linked but the radio is
  never used.)

## 2. Board settings (Tools menu)

| Setting | Value |
|---------|-------|
| Board | **ESP32C3 Dev Module** |
| **USB CDC On Boot** | **Enabled** ← REQUIRED: this is the data path the PC writes to |
| CPU Frequency | 160 MHz |
| Upload Speed | 921600 |
| Partition Scheme | **Huge APP (3MB No OTA/1MB SPIFFS)** — needed for ~1 MB of sprites |
| Port | the COM/tty port for the board |

> **USB CDC On Boot = Enabled is mandatory on the wired build.** With it disabled,
> `Serial` is routed to a hardware UART instead of the USB port, so the PC's events
> never reach the sketch and the mascot never reacts. This is the single most
> common reason a freshly flashed wired board sits frozen on its resting face.

## 3. Sprite headers — already bundled ← self-contained

All 13 `sprite_*.h` headers and `rle_sprite.h` ship **inside the sketch folder**
next to `clawd_mochi.ino`. There is nothing to copy and no external download —
just open the sketch and compile:

```
clawd_mochi/
└── clawd_mochi/
    ├── clawd_mochi.ino     ← open THIS in Arduino IDE
    ├── rle_sprite.h
    └── sprite_*.h          ← 13 expression headers, already here
```

> Arduino IDE requires the `.ino` to sit in a folder of the **same name**
> (`clawd_mochi/clawd_mochi.ino`). Keep the folder intact when you copy it.

## 4. No WiFi to configure

There is nothing to set up in the sketch and no on-device WiFi portal. Ship as-is.
The mascot is driven by the PC over USB; the only "pairing" is plugging it in.

## 5. Flash

1. Connect the board with a **data-capable** USB cable.
2. Select the right Port in Arduino IDE.
3. Click Upload. Success ends with `Hard resetting...`.

**If no COM/serial port appears:**
- Try a different USB cable (charge-only cables won't enumerate a port) and a
  direct USB port (not a hub).
- Force download mode: hold **BOOT**, tap **RST/RESET**, release **BOOT**, then
  upload; tap **RST** to run afterward.
- Check the OS device manager for an unknown/driver-less device.

## 6. Set up the PC side (one time)

1. Create `%USERPROFILE%\.codex\hooks\`.
2. Copy `clawd-mochi-cx/assets/clawd-mochi-codex.cmd`,
   `clawd-mochi-cx/assets/clawd-mochi-codex.ps1`, and
   `clawd-mochi-cx/assets/hooks.json` into that folder.
3. In the copied `hooks.json` template, replace `__HOOKS_DIR__` with the real
   hooks folder path, then merge its `hooks` object into
   `%USERPROFILE%\.codex\hooks.json`.
4. **Restart Codex**, run `/hooks`, and trust the Clawd Mochi hook entries.

That's it — no WiFi, no Python/Node, no background service. The script auto-finds
the board's COM port by its USB id (`VID_303A&PID_1001`) and caches it to
`%USERPROFILE%\.clawd_mochi_com`.

## 7. First run checklist

1. Plug the mascot into the **computer's** USB port with a **data** cable. It
   shows a splash and logo, then a green **"USB Ready"** screen, then relaxes to
   its sleeping face after ~8 s.
2. Test the sender by hand (PowerShell):
   ```powershell
   & "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State coding
   ```
   → the keyboard "coding" animation. Try `done`, `running`, `delegating`,
   `planning`, `compacting`, `notify`, `sleep`.
3. Confirm hooks: in Codex run `/hooks`. Then use Codex normally and
   watch the face follow along — press Enter → thinking sprite → done!

## 8. Operating notes

- The mascot must stay plugged into the **computer's USB port** during use — that
  one cable carries **both power and the events**. A phone charger / wall plug
  gives power but has no data path, so the mascot would just sit on its resting
  face. (You *can* run it off a charger purely as a desk ornament; it simply won't
  follow Codex.)
- Use a **USB DATA** cable, not a charge-only one.
- **Don't keep the Arduino Serial Monitor (or any other serial app) open** while
  using it — it holds the COM port and the hooks can't write to it. Close it.
- The COM number can change if you replug into a different socket; the sender
  re-detects automatically (and `SessionStart` forces a re-detect each session via
  the `force` argument).
- Because the C3 uses **native USB** (no DTR/RTS auto-reset circuit), the sender
  opening and closing the port dozens of times per turn does **not** reboot the
  mascot.

## 9. Troubleshooting

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Display dark | no power / charge-only cable / loose VCC | data cable, check 3V3 wire |
| Compile error: `sprite_idle.h: No such file` | sketch folder broken up / headers missing | keep `clawd_mochi.ino` and all `sprite_*.h` together in one folder |
| Compile error: not enough flash / program too large | wrong partition scheme | Tools → Partition Scheme → **Huge APP** |
| Boot shows "USB Ready" but never reacts | hooks not added, sender not copied, or Codex not restarted | do step 6; run `/hooks` to verify |
| Reacts to manual `...ps1 coding` test but not to Codex | hooks not loaded | restart Codex (hooks load at startup) |
| Nothing reacts at all, even the manual test | wrong port / charge-only cable / port held by another app | data cable; close Serial Monitor; re-run (re-detects); confirm the board enumerates a COM port |
| Port shows but no animation | flashed with **USB CDC On Boot = Disabled**, or old WiFi firmware | re-flash the wired sketch with **USB CDC On Boot = Enabled** |
| "running scripts is disabled" | PowerShell execution policy | the hook passes `-ExecutionPolicy Bypass`; add it when running by hand too |
| Can't flash, no serial port | charge-only cable / needs bootloader mode | data cable; hold BOOT + tap RST |
| Board list shows a wrong board (e.g. "Ozobot") | IDE didn't refresh after installing the esp32 core | restart the IDE; pick Tools → Board → esp32 → ESP32C3 Dev Module |
| COM number changed after replug | different USB socket | nothing to do — the sender re-detects and rewrites `%USERPROFILE%\.clawd_mochi_com` |
| Mascot reboots between events | (not expected on C3 native USB) opening the port reset the chip | report it — the sender keeps RTS deasserted to avoid this; DTR handling can be adjusted if your board behaves differently |
| Mascot sleeps after a long idle period | CX adapter idle timer fired | normal behavior; a new Codex prompt wakes it again |

