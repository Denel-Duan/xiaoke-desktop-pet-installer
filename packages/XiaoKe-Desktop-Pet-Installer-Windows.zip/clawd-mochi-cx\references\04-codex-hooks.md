# 04 - Codex Hook Integration (Wired USB)

This is the buyer-facing setup guide for making the wired USB mascot follow
Codex. The device firmware is already complete; this layer only installs the
Codex host adapter and writes one state word to the ESP32-C3 USB serial port.

## What Gets Installed

Copy these files from `assets/` into:

```text
%USERPROFILE%\.codex\hooks\
```

| File | Purpose |
|---|---|
| `clawd-mochi-codex.cmd` | Small Windows launcher used by Codex hooks |
| `clawd-mochi-codex.ps1` | Reads Codex hook JSON, classifies the event, writes USB serial |
| `hooks.json` | Template hook registration; merge into `%USERPROFILE%\.codex\hooks.json` |

The adapter uses Windows' built-in .NET serial port API. It does not require
Python, pyserial, WiFi, or a local web server.

## Install Steps

1. Plug the mascot into the PC with a **data-capable** USB-C cable.

2. Create the hooks folder:

   ```powershell
   New-Item -ItemType Directory -Force "$env:USERPROFILE\.codex\hooks"
   ```

3. Copy the three asset files into that folder.

4. Open the copied `assets/hooks.json` template and replace every
   `__HOOKS_DIR__` with the absolute hooks folder path. In JSON, backslashes must
   be doubled:

   ```json
   "C:\\Users\\your-name\\.codex\\hooks\\clawd-mochi-codex.cmd"
   ```

5. Merge the template's top-level `"hooks"` object into:

   ```text
   %USERPROFILE%\.codex\hooks.json
   ```

   If the file already exists, merge rather than overwrite.

6. Restart Codex, run `/hooks`, and trust the Clawd Mochi hook commands.

7. Test from PowerShell:

   ```powershell
   & "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State done
   ```

   The device should show the happy `done` animation, then return to rest.

## COM Port Detection

The sender first looks for the ESP32-C3 native USB identifier:

```text
VID_303A&PID_1001
```

This local installation also supports a single CH340 serial bridge identified
as `VID_1A86&PID_7523` or `VID_1A86&PID_5523`. DTR remains deasserted on CH340
ports so opening the port does not trigger the bridge board's auto-reset line.

It caches the detected COM port in the buyer's profile for fast follow-up events.
If the cached port stops working, the script re-detects the device so it can
recover when Windows renumbers the COM port.

If the port is busy or unplugged, the hook exits successfully and Codex keeps
running. The mascot simply misses that state update.

## macOS / Linux 安装（零依赖，无需 PowerShell）

Mac/Linux 用自带的 **bash + perl + stty** 版适配器 `clawd-mochi-codex.sh`，写串口
不需要 .NET，也不需要 Python/pyserial。行为与 Windows 版一致。

1. 用**数据线**把设备插到电脑，然后：

   ```bash
   mkdir -p ~/.codex/hooks
   cp clawd-mochi-codex.sh ~/.codex/hooks/
   chmod +x ~/.codex/hooks/clawd-mochi-codex.sh
   ```

2. 把 `hooks.macos.json` 里的 `"hooks"` 合并进 `~/.codex/hooks.json`。
   **命令里的 `$HOME` 由 shell 自动展开，不用改任何路径。**

3. 重启 Codex，`/hooks` 信任这些命令。测试：

   ```bash
   printf '{"hook_event_name":"Stop","last_assistant_message":"done"}' | bash ~/.codex/hooks/clawd-mochi-codex.sh
   ```

> macOS 串口要点（脚本已处理，排错备查）：
> - 自动找 `/dev/cu.usbmodem*`（C3 原生 USB，Mac 免驱）；用 `cu.*` 不用 `tty.*`。
> - CH340/CP2102 转接芯片的板子需先装 Mac 驱动，否则串口不出现。
> - 串口忙/被占用时静默退出，不阻塞 Codex。
> - 排错：`CLAWD_MOCHI_DEBUG=1` 写 `~/.clawd_mochi_codex.log`；`CLAWD_MOCHI_DRYRUN=1` 只打印状态。

## Event to Expression Mapping

The template intentionally sends all relevant Codex events to one adapter script.
The script performs the semantic classification, so WiFi / wired / BLE use the
same state logic.

| Codex event or tool category | Device state | Sprite |
|---|---|---|
| `SessionStart` | `idle` | `sprite_idle` |
| `UserPromptSubmit` | `thinking` | `sprite_thinking` |
| read/search/fetch/list tools, read-only shell commands | `reading` | `sprite_debugger` |
| apply/edit/write/patch tools, editing shell commands | `coding` | `sprite_typing` |
| shell commands, browser/computer tools, long-running commands | `running` | `sprite_building` |
| `SubagentStart`, task/thread handoff style tools | `delegating` | `sprite_conducting` |
| update-plan / plan-mode style tools | `planning` | `sprite_wizard` |
| `PermissionRequest`, AskUserQuestion, choice prompts before the buyer answers | `waiting` | `sprite_alert` |
| `PreCompact` | `compacting` | `sprite_sweeping` |
| notification-like / MCP / external-service attention events | `notify` | `sprite_beacon` |
| normal `Stop` | `done` | `sprite_happy` |
| explicit tool/subagent failure | `error` | `sprite_confused` |
| idle timer or CLI close watcher | `sleep` | `sprite_sleeping` |

Notes:

- Codex hook payloads require a little classification, so the script also
  inspects shell command text. Read-only commands become
  `reading`; file-changing commands become `coding`; other commands become
  `running`.
- `PostToolUse` repeats the same tool state unless an explicit failure flag is
  present. This keeps the working animation visible until the next real state.
- User-choice tools are the one intentional exception: `PreToolUse` shows
  `waiting`; once the buyer submits a choice, `PostToolUse` returns to
  `thinking` so the mascot no longer looks like it is still waiting.
- `done` is held for about five seconds to match the firmware's happy animation.
- The script filters Codex App internal helper sessions so prompt suggestions,
  titles, and summaries do not flicker the mascot after a real turn ends.
- Codex is not expected to provide a guaranteed close hook, so `sleep` is handled
  by a best-effort CLI close watcher and the idle sleep timer.

## Manual State Tests

Run any of these after installation:

```powershell
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State thinking
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State reading
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State coding
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State running
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State delegating
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State planning
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State compacting
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State notify
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State waiting
& "$env:USERPROFILE\.codex\hooks\clawd-mochi-codex.cmd" -State sleep
```

## Troubleshooting

| Symptom | Check |
|---|---|
| Manual test does nothing | Use a data cable, close Arduino Serial Monitor, confirm USB CDC is enabled in the flashed build |
| Hooks do nothing but manual test works | Restart Codex, run `/hooks`, trust the hook entries |
| Device resets when hooks run | The sender deasserts RTS; if reset persists, another serial app may be touching the port |
| COM port changed | Run `clawd-mochi-codex.cmd -State idle -Mode session-start` to force re-detection |
| `done` disappears too quickly | Ensure the shipped CX script has `$DoneHoldMs = 5200` |

Keep this document buyer-safe: do not ship developer paths, debug logs, or local
`.codex` trust records.
