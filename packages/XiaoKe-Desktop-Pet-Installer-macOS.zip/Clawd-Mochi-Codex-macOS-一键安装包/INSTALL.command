#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
SOURCE_SKILL="$SCRIPT_DIR/clawd-mochi-cx"
CODEX_HOME="$HOME/.codex"
HOOKS_DIR="$CODEX_HOME/hooks"
SKILL_DIR="$CODEX_HOME/skills/clawd-mochi-cx"
HOOKS_JSON="$CODEX_HOME/hooks.json"
TEMPLATE="$SOURCE_SKILL/assets/hooks.macos.json"
SENDER="$HOOKS_DIR/clawd-mochi-codex.sh"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$CODEX_HOME/mochi-backups/$STAMP"

step() { printf '\n\033[36m==> %s\033[0m\n' "$1"; }
warn() { printf '\033[33m%s\033[0m\n' "$1"; }
ok()   { printf '\033[32m%s\033[0m\n' "$1"; }

if [ "$(uname -s)" != "Darwin" ]; then
  echo "This installer is for macOS only."
  exit 1
fi
if [ ! -f "$SOURCE_SKILL/SKILL.md" ] || [ ! -f "$TEMPLATE" ]; then
  echo "安装包不完整，请保留并解压整个文件夹。"
  exit 1
fi

step "备份现有配置"
mkdir -p "$HOOKS_DIR" "$CODEX_HOME/skills" "$BACKUP_DIR"
for path in "$HOOKS_JSON" "$HOOKS_DIR/clawd-mochi-codex.sh"; do
  if [ -f "$path" ]; then
    cp -p "$path" "$BACKUP_DIR/$(basename "$path")"
  fi
done

step "安装 Clawd Mochi Skill 和串口脚本"
mkdir -p "$SKILL_DIR"
cp -R "$SOURCE_SKILL/." "$SKILL_DIR/"
cp "$SOURCE_SKILL/assets/clawd-mochi-codex.sh" "$SENDER"
cp "$TEMPLATE" "$HOOKS_DIR/hooks.macos.template.json"
chmod 755 "$SENDER"

step "合并 Codex Hooks（保留其他已有 Hook）"
/usr/bin/osascript -l JavaScript "$SCRIPT_DIR/merge-hooks.js" "$HOOKS_JSON" "$TEMPLATE"
ok "Hooks 已写入：$HOOKS_JSON"

step "检测 Mochi 串口"
shopt -s nullglob
native_ports=(/dev/cu.usbmodem*)
bridge_ports=(/dev/cu.wchusbserial* /dev/cu.SLAB_USBtoUART* /dev/cu.usbserial*)
ports=()
if [ "${#native_ports[@]}" -gt 0 ]; then
  ports=("${native_ports[@]}")
else
  ports=("${bridge_ports[@]}")
fi

selected=""
if [ "${#ports[@]}" -eq 1 ]; then
  selected="${ports[0]}"
elif [ "${#ports[@]}" -gt 1 ]; then
  echo "发现多个候选串口："
  printf '  %s\n' "${ports[@]}"
  read -r -p "请输入 Mochi 的完整串口路径：" selected
fi

if [ -n "$selected" ] && [ -e "$selected" ]; then
  printf '%s' "$selected" > "$HOME/.clawd_mochi_com"
  ok "已选择：$selected"

  step "发送测试表情"
  CLAWD_MOCHI_DEBUG=1 bash "$SENDER" --state thinking || true
  sleep 1
  CLAWD_MOCHI_DEBUG=1 bash "$SENDER" --state done || true
  ok "已发送 thinking 和 done；设备应显示对应动画。"
else
  warn "未自动找到串口。请确认数据线；CH340/CP210x 机型还需对应的 macOS 驱动。"
  warn "文件安装已完成，连接设备后可再次运行本安装器。"
fi

step "完成一次 Codex Hook 信任"
if command -v codex >/dev/null 2>&1; then
  warn "即将打开 Codex 终端。请输入 /hooks，确认 Mochi Hooks 的 Active 为 1。"
  warn "完成后按 Esc，再按 Ctrl+C 返回安装器。"
  read -r -p "按回车打开 Codex..." _
  codex || true
else
  warn "未在 PATH 中找到 codex 命令。请先安装/启用 Codex CLI，再运行 codex 并输入 /hooks。"
  read -r -p "按回车继续..." _
fi

step "打开 Codex 桌面端"
if pgrep -if '/Codex.app/' >/dev/null 2>&1; then
  warn "桌面端正在运行，必须重启才能读取刚信任的 Hooks。"
  read -r -p "确认没有任务正在执行后，输入 Y 自动重启；其他内容跳过：" choice
  if printf '%s' "$choice" | grep -iqE '^y(es)?$'; then
    /usr/bin/osascript -e 'tell application "Codex" to quit' >/dev/null 2>&1 || true
    sleep 3
  fi
fi

if /usr/bin/open -a Codex >/dev/null 2>&1; then
  ok "Codex 桌面端已打开。发送普通消息即可测试 Mochi。"
else
  warn "未找到 Codex.app，请手动打开 Codex 桌面端。"
fi

printf '\n安装完成。备份目录：%s\n' "$BACKUP_DIR"
read -r -p "按回车关闭窗口..." _

