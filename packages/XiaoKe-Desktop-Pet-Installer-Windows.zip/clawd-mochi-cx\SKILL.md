---
name: clawd-mochi-cx
description: >
  Buyer-facing setup and builder reference for the wired USB "Clawd Mochi CX"
  Codex edition: an ESP32-C3 + ST7789 desk mascot that mirrors Codex CLI/App
  activity as 13 pixel-art sprite expressions over USB serial hooks. Use this
  skill when setting up, installing, explaining, troubleshooting, or customizing
  the Codex wired package, including hooks.json, clawd-mochi-codex.ps1, COM-port
  auto-detection, /hooks trust, event-to-expression mapping, firmware behavior,
  or owner onboarding for the wired version.
---

# Clawd Mochi CX - Wired USB Codex Edition

This package is the Codex-facing skill for the **wired USB** version of Clawd
Mochi. The firmware is already the new 13-expression sprite build; the Codex
layer writes one state word to the ESP32-C3 USB serial port for each hook event.

Use this skill when the buyer wants the mascot to work without WiFi.

## Quick Setup Path

For installation, read and follow `references/04-codex-hooks.md`.

> **先判断平台，再选安装路径。** 你通常能直接从运行环境得知用户系统
> （`Platform: win32` = Windows，`darwin` = macOS）——**能判断就自动选择，
> 不用多问**；拿不准再问「你用的是 Windows 还是 macOS？」。
> - **Windows** → 下面默认步骤（`clawd-mochi-codex.cmd` + `.ps1` + `hooks.json`）。
> - **macOS / Linux** → 改用 `clawd-mochi-codex.sh` + `hooks.macos.json`（见本节末 macOS 短版）。

The short version (Windows):

1. Use a **data-capable** USB-C cable and keep the mascot plugged into the PC.
2. Copy `assets/clawd-mochi-codex.cmd`, `assets/clawd-mochi-codex.ps1`, and
   `assets/hooks.json` into `%USERPROFILE%\.codex\hooks\`.
3. Edit the copied `hooks.json` template by replacing `__HOOKS_DIR__` with that
   absolute hooks path, using escaped backslashes.
4. Merge the template's `hooks` object into `%USERPROFILE%\.codex\hooks.json`.
5. Restart Codex, run `/hooks`, trust the Clawd Mochi hooks, then test:
   `clawd-mochi-codex.cmd -State done`.

**macOS / Linux（零依赖 bash 版）：** 改用 `assets/clawd-mochi-codex.sh` +
`assets/hooks.macos.json`——拷进 `~/.codex/hooks/` 并 `chmod +x`，合并
`hooks.macos.json` 的 `hooks`。脚本自动找 `/dev/cu.usbmodem*`（C3 原生 USB，Mac 免驱）。
详见 `references/04-codex-hooks.md` 的「macOS / Linux 安装」一节。

The sender prefers the ESP32-C3 native USB COM port (`VID_303A&PID_1001`) and
also detects a single CH340 bridge (`VID_1A86&PID_7523` or `PID_5523`). It caches
the working port under the buyer's user profile and retries detection if the
cached port stops working.

## Codex State Model

The wired firmware accepts the same 13 states as WiFi:

`idle`, `thinking`, `reading`, `coding`, `running`, `delegating`, `planning`,
`waiting`, `compacting`, `notify`, `done`, `error`, `sleep`.

The Codex adapter keeps the hook surface small: all common Codex hook events call
one PowerShell script, and the script classifies the event/tool into the right
state. This avoids one-hook-per-expression drift.

| Codex source | Device state | Sprite |
|---|---|---|
| `SessionStart` | `idle` | idle bob |
| `UserPromptSubmit` | `thinking` | particle swirl |
| read/search/fetch/list tools or read-only shell commands | `reading` | debugger scanner |
| apply/edit/write/patch tools or editing shell commands | `coding` | typing |
| shell commands, browser/computer actions, long-running commands | `running` | building crane |
| subagent/thread handoff/task style tools | `delegating` | conducting |
| plan/update-plan style tools | `planning` | wizard |
| `PermissionRequest`, AskUserQuestion, user-choice prompts | `waiting` | alert flash |
| `PreCompact` | `compacting` | sweeping |
| notification/MCP/external-service attention events | `notify` | beacon |
| normal `Stop` | `done` | happy bounce, then idle |
| explicit tool/subagent failure | `error` | confused |
| CLI close watcher or idle sleep timer | `sleep` | sleeping |

## Reference Files

| File | Use it for |
|---|---|
| `references/01-overview-architecture.md` | Buyer-safe architecture overview |
| `references/02-hardware-wiring.md` | Hardware wiring |
| `references/03-firmware-design.md` | Firmware state machine and sprite renderer |
| `references/04-codex-hooks.md` | Codex hook install, trust, testing, mapping |
| `references/05-serial-protocol.md` | USB serial line protocol |
| `references/06-expressions-and-arbitration.md` | 13 sprites and active/resting behavior |
| `references/07-setup-and-flashing.md` | Arduino flash and first-run checklist |

## Important Boundaries

- Do not edit `clawd_mochi/clawd_mochi/clawd_mochi.ino` for Codex adaptation.
- Do not edit any `clawd-mochi-cc` directory when working on CX.
- Keep buyer docs sanitized: use `%USERPROFILE%` and
  `%USERPROFILE%\.codex\hooks\` instead of local developer paths.
- Keep the three transport variants behaviorally aligned; only the sender differs.

Independent maker project inspired by the open-source clawd-tank sprite work
(MIT). Not affiliated with or endorsed by OpenAI or Anthropic.
