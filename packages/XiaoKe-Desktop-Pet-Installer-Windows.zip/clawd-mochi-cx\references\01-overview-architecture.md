﻿# 01 · Overview & Architecture

## The idea

A coding session has rhythm: you think, Codex reads your code, writes a patch,
runs the tests, spawns a subagent, asks you a question, finishes. **Clawd Mochi
CX** turns that invisible rhythm into a physical, glanceable desk companion. The
mascot plays a different pixel-art animation for each Codex state —
**thirteen** animations in all.

This is the **wired (USB serial) edition**: the mascot plugs straight into your
computer's USB port, and that one **data** cable carries both power and the
events. There is no WiFi, no HTTP, no network at all.

## System diagram

```
            COMPUTER (running Codex)                 DEVICE (Clawd Mochi)
 ┌──────────────────────────────────────────┐     ┌──────────────────────────────┐
 │  Codex                              │     │  ESP32-C3 Super Mini         │
 │   │                                       │     │   • USB CDC serial @115200   │
 │   │ fires hooks on every event            │     │   • sprite state machine     │
 │   ▼                                       │ USB │   • RLE sprite decoder        │
 │  hooks.json hooks ── PowerShell ────────────►   serialTick → applyState     │
 │   (SessionStart, UserPromptSubmit,        │ data│        │                     │
 │    PreToolUse/PostToolUse, PreCompact,    │ cable│       ▼                     │
 │    PermissionRequest, Notification, Stop) │     │   ST7789 240×240 display     │
 │   clawd-mochi-codex.ps1 <state>           │     │                              │
 └──────────────────────────────────────────┘     └──────────────────────────────┘
        ▲                                                   ▲
        │ you type, approve permissions                     │ optional resting-look
        │                                                   │ face:/bg:/light: lines
```

Two independent inputs feed one screen:

1. **Codex** (automatic) — pushes a state word on every activity.
2. **You** (manual) — optionally pick a resting face + background color by
   sending `face:`/`bg:`/`light:` serial lines.

An **arbitration rule** decides which wins (see `06`).

## Data flow, end to end

The PC writes one word per line to the device's USB serial port; the firmware's
`serialTick()` reads it in `loop()` and `applyState()` switches the sprite.

1. You press Enter → `UserPromptSubmit` → sender writes `thinking\n` → thinking sprite starts.
2. Codex reads, searches, fetches, lists, or runs a read-only command → `reading\n` → debugger-scan animation.
3. Codex applies a patch, edits, writes, or runs a file-changing command → `coding\n` → typing fingers animation.
4. Codex runs shell/browser/computer work or a long command → `running\n` → crane/building animation.
5. Codex starts a subagent or thread handoff → `delegating\n` → conductor animation.
6. Codex updates or presents a plan → `planning\n` → wizard animation.
7. Codex needs your approval or a choice → `waiting\n` → alert-flash animation.
8. Codex compacts context → `compacting\n` → sweeping animation.
9. Codex emits a notification or external-service attention event → `notify\n` → beacon pulse.
10. Codex finishes normally → `done\n` → happy bounce, auto-relaxes after ~5 s.
11. A tool or subagent explicitly fails → `error\n` → confused animation.
12. You leave it idle or close a CLI session → idle timer / close watcher → `sleep\n` → slow sleeping Zzz.

## Design principles

- **Never block the human's tool.** The sender is fire-and-forget: it opens the
  COM port, writes one line, closes, and swallows every error. If the mascot is
  unplugged or its port is held by another app, the hook returns immediately and
  Codex is unaffected.

- **Push, don't poll.** The PC pushes state on each event. The device never asks
  the PC for anything — it just reads bytes as they arrive.

- **Discrete events, continuous animation.** One serial line starts a looping
  sprite; `loop()` advances frames until the next line. The mascot looks alive
  between events.

- **Tolerate missing/late events.** "done" auto-relaxes; working states time out
  after 120 s; "thinking" is held a minimum time so it's always visible.

- **Waiting vs. working is a first-class distinction.** `PermissionRequest` +
  `PostToolUse` correct the sprite from "working" to "waiting" during a permission
  prompt, then back to "working" after approval.

- **Two owners, clear priority.** Codex owns the screen while active (fixed
  orange look). Your manual resting selection owns the rest of the time.

- **Wiring, not pairing.** The only setup is plugging the cable in. No SSID, no
  IP, no `.local` name, no config portal.

## Sprite source

All 13 sprite animation headers (`.h` files) ship **inside the sketch folder**
next to `clawd_mochi.ino`, so the firmware compiles with no external downloads.
They are RLE-compressed RGB565 C arrays; the artwork derives from the open-source
[clawd-tank](https://github.com/marciogranzotto/clawd-tank) project (MIT). The
firmware's `drawSpriteFrame()` decodes them frame-by-frame into a shared SRAM
buffer and scales each to a uniform on-screen size.

## What's different from the WiFi edition

The wired firmware is the **same sketch** with the transport swapped. The network
layer (`WiFi`, `WebServer`, `ESPmDNS`, the NVS WiFi config, the phone web
controller, every `/event` and `/cmd` HTTP route, `clawd-mochi.local` mDNS) is
still `#include`d for source compatibility but **never runs** — at runtime the
firmware only reads the USB serial port. See `references/03` and `references/05`.

## Bill of complexity

| Layer | Size (approx) | Notes |
|-------|----------------|-------|
| Hardware | — | 8 wires + 1 USB data cable to the PC |
| Sprite headers | ~1 MB flash | 13 `.h` files, bundled in the sketch folder |
| Firmware | ~1,500 C++ | single `.ino`, no external state |
| Hooks | ~1 JSON file | declarative PowerShell commands |
| PC sender | ~70 lines PowerShell | zero-dependency, uses built-in .NET `SerialPort` |

