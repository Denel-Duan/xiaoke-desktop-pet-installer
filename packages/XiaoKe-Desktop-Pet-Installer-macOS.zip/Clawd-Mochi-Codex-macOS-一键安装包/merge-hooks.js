ObjC.import('Foundation');

function readText(path) {
  const value = $.NSString.stringWithContentsOfFileEncodingError(
    $(path),
    $.NSUTF8StringEncoding,
    null
  );
  if (!value) throw new Error('Cannot read: ' + path);
  return ObjC.unwrap(value);
}

function writeText(path, text) {
  const value = $(text);
  const ok = value.writeToFileAtomicallyEncodingError(
    $(path),
    true,
    $.NSUTF8StringEncoding,
    null
  );
  if (!ok) throw new Error('Cannot write: ' + path);
}

function run(argv) {
  const destination = argv[0];
  const templatePath = argv[1];
  const fm = $.NSFileManager.defaultManager;
  let config = {};

  if (fm.fileExistsAtPath($(destination))) {
    config = JSON.parse(readText(destination));
  }
  if (!config.hooks || typeof config.hooks !== 'object') config.hooks = {};

  const template = JSON.parse(readText(templatePath));
  Object.keys(template.hooks).forEach(function (eventName) {
    const existing = Array.isArray(config.hooks[eventName])
      ? config.hooks[eventName]
      : [];
    const kept = existing.filter(function (group) {
      return JSON.stringify(group).indexOf('clawd-mochi-codex.sh') === -1;
    });
    const incoming = JSON.parse(JSON.stringify(template.hooks[eventName]));
    config.hooks[eventName] = kept.concat(incoming);
  });

  writeText(destination, JSON.stringify(config, null, 2) + '\n');
  return 'Merged ' + Object.keys(template.hooks).length + ' Mochi hook events.';
}

