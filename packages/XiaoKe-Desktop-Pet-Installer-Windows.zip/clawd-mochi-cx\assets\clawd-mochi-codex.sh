#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════╗
#  Clawd Mochi —— Codex 适配器 · 有线(USB 串口)版  (macOS / Linux, 零依赖)
#
#  作用：Codex 每次触发 hook 时把一段 JSON 从 stdin 喂给本脚本；脚本判断事件
#        (读代码/写文件/跑命令/等待/完成…)，映射成状态字，通过 USB 串口写给
#        Clawd Mochi 设备(一行一个状态字，115200 8N1)。
#
#  零依赖：只用 macOS 自带 bash + perl + stty，无需 Python/pyserial/PowerShell。
#        行为对齐 Windows 版 .ps1(状态映射 + done 回落 + 空闲 sleep + 关闭转 sleep)。
#
#  串口：优先 C3 原生 USB 的 /dev/cu.usbmodem*(mac) 或 /dev/ttyACM*(linux)，
#        缓存到 ~/.clawd_mochi_com；换口自动重探。mac 用 /dev/cu.*(非 /dev/tty.*)。
#
#  调试：CLAWD_MOCHI_DEBUG=1 → ~/.clawd_mochi_codex.log；CLAWD_MOCHI_DRYRUN=1 只打印状态。
# ╚══════════════════════════════════════════════════════════════╝
set +e

STATE=""; MODE="hook"; TOKEN=""; WATCH_PID=""
while [ $# -gt 0 ]; do
  case "$1" in
    --state) STATE="$2"; shift 2 ;;
    --mode)  MODE="$2";  shift 2 ;;
    --token) TOKEN="$2"; shift 2 ;;
    --watchpid) WATCH_PID="$2"; shift 2 ;;
    *) shift ;;
  esac
done

SELF="$0"
STATE_FILE="$HOME/.clawd_mochi_codex.state"   # state<TAB>updatedAtMs<TAB>token<TAB>suppressUntilMs<TAB>idleSleepDueMs
LOG_FILE="$HOME/.clawd_mochi_codex.log"
COM_CACHE="$HOME/.clawd_mochi_com"

DUP_WINDOW_MS=300
POST_STOP_SUPPRESS_MS=7000
DONE_HOLD_MS=5200
IDLE_SLEEP_MS=180000

VALID="idle thinking reading coding running delegating planning waiting compacting notify done error sleep"

log()      { [ "$CLAWD_MOCHI_DEBUG" = "1" ] && printf '%s %s\n' "$(date +%FT%T)" "$*" >> "$LOG_FILE" 2>/dev/null; return 0; }
now_ms()   { perl -MTime::HiRes=time -e 'printf "%.0f", time()*1000' 2>/dev/null || echo 0; }
sleep_ms() { perl -e 'select(undef,undef,undef,$ARGV[0]/1000)' "$1" 2>/dev/null || sleep $(( ${1%.*} / 1000 )); }
is_valid() { case " $VALID " in *" $1 "*) return 0;; *) return 1;; esac; }
spawn()    { nohup bash "$@" >/dev/null 2>&1 & disown 2>/dev/null; return 0; }

read_state_field() { [ -f "$STATE_FILE" ] && cut -f"$1" "$STATE_FILE" 2>/dev/null; }
save_state() { printf '%s\t%s\t%s\t%s\t%s\n' "$1" "$(now_ms)" "$2" "${3:-0}" "${4:-0}" > "$STATE_FILE" 2>/dev/null; }

# ╭───────────────────────────────────────────────────────────────╮
# │  发送实现 —— 有线版：写 USB 串口 /dev/cu.*(mac) / /dev/ttyACM*(linux) │
# ╰───────────────────────────────────────────────────────────────╯
STTY_F="-f"; [ "$(uname 2>/dev/null)" = "Linux" ] && STTY_F="-F"
list_ports() {
  ls /dev/cu.usbmodem* /dev/ttyACM* 2>/dev/null
  ls /dev/cu.wchusbserial* /dev/cu.SLAB_USBtoUART* /dev/cu.usbserial* /dev/ttyUSB* 2>/dev/null
}
write_port() { # $1=port $2=state
  local port="$1"
  [ -n "$port" ] && [ -e "$port" ] || return 1
  stty $STTY_F "$port" 115200 cs8 -cstopb -parenb -crtscts clocal -hupcl 2>/dev/null
  printf '%s\n' "$2" > "$port" 2>/dev/null || return 1
  return 0
}
send_state() { # $1=state
  local s="$1" port
  port="$(cat "$COM_CACHE" 2>/dev/null | tr -d ' \r\n')"
  if [ -n "$port" ] && write_port "$port" "$s"; then log "send-ok $s via=$port"; return 0; fi
  port="$(list_ports | head -1)"
  if [ -n "$port" ]; then
    printf '%s' "$port" > "$COM_CACHE" 2>/dev/null
    write_port "$port" "$s" && { log "send-ok $s via=$port(detected)"; return 0; }
  fi
  log "send-FAIL $s (no serial port)"; return 1
}
# ╰───────────────────────────────────────────────────────────────╯

emit() { # $1=state $2=force $3=token $4=suppressUntilMs
  local s="$1" force="${2:-0}" token="${3:-$TOKEN}" suppress="${4:-0}" idleDue=0
  is_valid "$s" || s="idle"
  [ "$s" = "idle" ] && idleDue=$(( $(now_ms) + IDLE_SLEEP_MS ))
  if [ "$force" != "1" ]; then
    local prev prevTs age; prev="$(read_state_field 1)"; prevTs="$(read_state_field 2)"
    if [ "$prev" = "$s" ] && [ -n "$prevTs" ]; then
      age=$(( $(now_ms) - prevTs ))
      [ "$age" -ge 0 ] && [ "$age" -lt "$DUP_WINDOW_MS" ] && { log "skip-dup $s"; return 0; }
    fi
  fi
  if [ "$CLAWD_MOCHI_DRYRUN" = "1" ]; then echo "$s"; save_state "$s" "$token" "$suppress" "$idleDue"; return 0; fi
  send_state "$s"; save_state "$s" "$token" "$suppress" "$idleDue"
}

start_done_return()   { spawn "$SELF" --mode done-return --token "$1"; }
start_idle_sleep()    { spawn "$SELF" --mode idle-sleep  --token "$1"; }
find_codex_pid() {
  local pid=$PPID i=0 comm ppid
  while [ "$i" -lt 16 ] && [ -n "$pid" ] && [ "$pid" -gt 1 ]; do
    comm=$(ps -o comm= -p "$pid" 2>/dev/null)
    case "$comm" in *codex*|*Codex*) echo "$pid"; return;; esac
    ppid=$(ps -o ppid= -p "$pid" 2>/dev/null | tr -d ' '); [ -n "$ppid" ] || break
    pid=$ppid; i=$((i+1))
  done
  echo ""
}
start_close_watcher() {
  local wp; wp="$(find_codex_pid)"
  [ -n "$wp" ] || { log "watch-skip no-codex-ancestor"; return; }
  spawn "$SELF" --mode watch-cli --token "$1" --watchpid "$wp"
}

case "$MODE" in
  done-return)
    sleep_ms "$DONE_HOLD_MS"
    [ "$(read_state_field 1)" = "done" ] || exit 0
    emit idle 1 "$TOKEN" 0; start_idle_sleep "$TOKEN"; exit 0 ;;
  idle-sleep)
    sleep_ms "$IDLE_SLEEP_MS"
    [ "$(read_state_field 1)" = "idle" ] || exit 0
    due="$(read_state_field 5)"
    { [ -n "$due" ] && [ "$due" -gt 0 ] 2>/dev/null && [ "$(now_ms)" -lt "$due" ]; } && exit 0
    emit sleep 1 "$TOKEN" 0; exit 0 ;;
  watch-cli)
    [ -n "$WATCH_PID" ] || exit 0
    while kill -0 "$WATCH_PID" 2>/dev/null; do sleep 0.5; done
    sleep 0.3
    if command -v pgrep >/dev/null 2>&1; then pgrep -i codex >/dev/null 2>&1 && exit 0
    else ps ax 2>/dev/null | grep -iq "[c]odex" && exit 0; fi
    emit sleep 1 "$TOKEN" 0; exit 0 ;;
esac

PAYLOAD=""
field() {
  [ -n "$PAYLOAD" ] || { echo ""; return; }
  printf '%s' "$PAYLOAD" | perl -0777 -ne 'BEGIN{$f=shift}
    for my $k (split/\|/,$f){ if(/"\Q$k\E"\s*:\s*"((?:[^"\\]|\\.)*)"/){ my $v=$1; $v=~s/\\(["\\\/])/$1/g; print $v; exit } }' "$1"
}
pmatch() { printf '%s' "$PAYLOAD" | grep -iqE "$1"; }

tool_state() {
  local tool cmd; tool="$(field 'tool_name|toolName|name')"; cmd="$(field 'command|cmd|script')"
  case "$tool" in *AskUserQuestion*|*request_user_input*|*request-user-input*|*user_input*|*select_option*|*choose_option*) echo waiting; return;; esac
  echo "$tool" | grep -iqE 'ExitPlanMode|update_plan|plan_mode|plan-mode|planning' && { echo planning; return; }
  echo "$tool" | grep -iqE 'Subagent|Task|multi_agent|handoff_thread|send_message_to_thread|create_thread|fork_thread' && { echo delegating; return; }
  echo "$tool" | grep -iqE 'apply_patch|^(Edit|Write|MultiEdit|NotebookEdit)$|edit|write|patch|file_write' && { echo coding; return; }
  if echo "$tool" | grep -iqE '^(Bash|Shell|Command)$|shell_command|terminal|exec'; then
    echo "$cmd" | grep -iqE '\b(apply_patch|git[[:space:]]+(apply|add|commit|checkout|restore|reset|clean)|rm|mv|cp|tee|sed[[:space:]]+-i)\b|>[>]?' && { echo coding; return; }
    echo "$cmd" | grep -iqE '^[[:space:]]*(cat|less|head|tail|rg|grep|ls|find|pwd|stat|file|git[[:space:]]+(status|show|diff|log|branch|rev-parse)|docker[[:space:]]+ps|docker[[:space:]]+logs)\b' && { echo reading; return; }
    echo running; return
  fi
  echo "$tool" | grep -iqE 'compact|summari[sz]e_context' && { echo compacting; return; }
  echo "$tool" | grep -iqE 'mcp__|automation|reminder|monitor|notification|notify|linear|jira|slack' && { echo notify; return; }
  echo "$tool" | grep -iqE 'node_repl|computer|browser|chrome' && { echo running; return; }
  echo "$tool" | grep -iqE 'read|search|fetch|open|find|list|get|resolve|context7|everything|web|finance|weather|sports|time' && { echo reading; return; }
  echo "$tool" | grep -iqE 'create|update|move|delete|write|edit|patch|apply' && { echo coding; return; }
  echo running
}

is_internal_app_session() {
  pmatch '\\?"suggestions\\?"[[:space:]]*:[[:space:]]*\[' && return 0
  pmatch 'ambient[-_ ]?suggestions|followUpQueue' && return 0
  return 1
}

state_from_payload() {
  local ev; ev="$(field 'hook_event_name|hookEventName')"
  case "$ev" in
    SessionStart)      echo idle ;;
    UserPromptSubmit)  echo thinking ;;
    PermissionRequest) echo waiting ;;
    PreToolUse)        tool_state ;;
    PostToolUse)
      pmatch '"(isError|error|failed|failure)"[[:space:]]*:[[:space:]]*true' && { echo error; return; }
      local t; t="$(field 'tool_name|toolName|name')"
      echo "$t" | grep -iqE 'AskUserQuestion|request_user_input|user_input' && { echo thinking; return; }
      tool_state ;;
    PreCompact)        echo compacting ;;
    PostCompact)       echo thinking ;;
    SubagentStart)     echo delegating ;;
    SubagentStop)
      pmatch 'failed|failure|error|exception|crash|timed out|unable to|could not|not able to|blocked|denied|失败|报错|错误|异常|未能|无法|被拒绝|被阻止' && { echo error; return; }
      echo thinking ;;
    Notification)
      pmatch 'interrupted|interrupt|cancelled|canceled|aborted|paused|中断|取消|暂停' && { echo idle; return; }
      pmatch 'permission|approval|approve|allow|deny|confirm|choose|choice|select|submit|askuserquestion|是否|选择|确认|提交|允许|批准|授权' && { echo waiting; return; }
      echo notify ;;
    Stop)
      pmatch 'interrupted|interrupt|cancelled|canceled|aborted|中断|取消' && { echo idle; return; }
      local m; m="$(field 'last_assistant_message|lastAssistantMessage|message')"
      if [ -n "$m" ] && [ "${#m}" -le 160 ] && printf '%s' "$m" | grep -qE '[?？][[:space:]]*$'; then echo waiting; return; fi
      echo done ;;
    SessionEnd)        echo sleep ;;
    *)                 echo idle ;;
  esac
}

# ══════════════════ 主流程 ══════════════════
if [ -n "$STATE" ]; then
  [ -n "$TOKEN" ] || TOKEN="$(now_ms)$$"
  emit "$STATE" 1 "$TOKEN" 0
  if [ "$MODE" = "session-start" ]; then
    start_idle_sleep "$TOKEN"; start_close_watcher "$TOKEN"
  elif [ "$STATE" = "idle" ]; then
    start_idle_sleep "$TOKEN"
  fi
  exit 0
fi

[ -t 0 ] || PAYLOAD="$(cat 2>/dev/null)"
[ -n "$PAYLOAD" ] || { log "empty-payload"; exit 0; }
is_internal_app_session && { log "skip-internal-app-session"; exit 0; }

EVENT="$(field 'hook_event_name|hookEventName')"
NEXT="$(state_from_payload)"

IS_START=0; [ "$EVENT" = "SessionStart" ] && IS_START=1
if [ "$IS_START" = "1" ]; then
  TOKEN="$(field 'session_id|sessionId')"; [ -n "$TOKEN" ] || TOKEN="$(now_ms)$$"
else
  TOKEN="$(read_state_field 3)"
fi

case "$EVENT" in
  SessionStart|UserPromptSubmit|PermissionRequest|Notification|Stop|SessionEnd) : ;;
  *)
    su="$(read_state_field 4)"
    { [ -n "$su" ] && [ "$su" -gt 0 ] 2>/dev/null && [ "$(now_ms)" -lt "$su" ]; } && { log "skip-post-stop $EVENT"; exit 0; } ;;
esac

SUPPRESS=0
{ [ "$EVENT" = "Stop" ] || { [ "$EVENT" = "Notification" ] && pmatch 'interrupted|cancelled|canceled|中断|取消'; }; } && SUPPRESS=$(( $(now_ms) + POST_STOP_SUPPRESS_MS ))

FORCE=0
{ [ "$IS_START" = "1" ] || [ "$NEXT" = "sleep" ] || [ "$NEXT" = "idle" ] || [ "$NEXT" = "waiting" ] || [ "$NEXT" = "done" ]; } && FORCE=1

log "evt=$EVENT -> $NEXT token=$TOKEN"
emit "$NEXT" "$FORCE" "$TOKEN" "$SUPPRESS"

[ "$EVENT" = "Stop" ] && [ "$NEXT" = "done" ] && start_done_return "$TOKEN"
[ "$NEXT" = "idle" ] && start_idle_sleep "$TOKEN"
[ "$IS_START" = "1" ] && start_close_watcher "$TOKEN"
exit 0
